# DriftFinder — Claude Code Build Specification

> **READ THIS ENTIRE DOCUMENT BEFORE WRITING A SINGLE LINE OF CODE.**
> This document is the single source of truth for the DriftFinder project.
> It defines two phases. Build Phase 1 completely before touching Phase 2.
> This is a research project. We learn and tweak as we go.
> When something does not work as expected, document it and adapt.
> Production-grade standards apply from day one.

---

## Table of Contents

1. [Project Context](#1-project-context)
2. [What DriftFinder Is](#2-what-driftfinder-is)
3. [Two-Phase Architecture Overview](#3-two-phase-architecture-overview)
4. [Repository Structure](#4-repository-structure)
5. [Technology Stack](#5-technology-stack)
6. [The Normalised Resource Model (NRM) — Complete Specification](#6-the-normalised-resource-model-nrm--complete-specification)
7. [AWS API Mappings — Complete Specification](#7-aws-api-mappings--complete-specification)
8. [CIS Control Mappings — Complete Specification](#8-cis-control-mappings--complete-specification)
9. [IaC Parser Specifications](#9-iac-parser-specifications)
10. [Phase 1 — Dissertation Version (BUILD THIS FIRST)](#10-phase-1--dissertation-version-build-this-first)
11. [Phase 2 — Full Production Version](#11-phase-2--full-production-version)
12. [CLI Specification — Complete](#12-cli-specification--complete)
13. [Test Strategy](#13-test-strategy)
14. [Security Requirements](#14-security-requirements)
15. [CI/CD Pipeline](#15-cicd-pipeline)
16. [Distribution](#16-distribution)
17. [Documentation Requirements](#17-documentation-requirements)
18. [Research Notes and Known Challenges](#18-research-notes-and-known-challenges)

---

## 1. Project Context

DriftFinder is an academic research project being developed as part of an MSc dissertation in Data Science and Big Data Analytics at Wrexham University, and subsequently as a production-grade open source tool.

The researcher has three years of professional experience managing CloudFormation infrastructure in a PCI-DSS-regulated fintech environment. The researcher is AWS Solutions Architect certified. The tool addresses a problem encountered directly in professional practice.

The dissertation proves the concept. The full version ships to the world.

**This is iterative research.** If you encounter an AWS API that behaves differently from the specification, document the discrepancy, adapt the implementation, and update the relevant section. Do not silently work around problems. Surface them clearly.

**The project name is DriftFinder.** The GitHub repository will be `driftfinder`. The PyPI package will be `driftfinder`. The npm package will be `@driftfinder/sdk`.

**Licence:** Apache 2.0 for all code. CC BY 4.0 for all documentation.

---

## 2. What DriftFinder Is

DriftFinder is an open source developer tool that detects Infrastructure as Code drift between declared IaC state and live AWS runtime state.

**What it does:**
- Reads declared infrastructure state from Terraform (.tfstate), CloudFormation (AWS API), or Pulumi (stack export)
- Queries live AWS resource state via Boto3 SDK
- Compares the two through a Normalised Resource Model (NRM)
- Detects property-level divergences
- Maps each divergence to a specific CIS AWS Foundations Benchmark v3.0 control
- Reports findings with severity (CRITICAL, HIGH, MEDIUM, LOW)
- Outputs JSON for CI/CD consumption and HTML for audit evidence

**What it does NOT do:**
- It does not read IaC source code directly (only serialised state)
- It does not automatically apply fixes without explicit user invocation (Phase 2 remediation is always explicit)
- It does not collect or transmit user data anywhere
- It does not require internet access beyond AWS API calls

**CDK note:** CDK users are covered automatically by the CloudFormation adapter. CDK synthesises to CloudFormation before deployment. DriftFinder reads the resulting CloudFormation stack via the same API with no CDK-specific handling required.

**The core research contribution is the NRM.** The NRM abstracts tool-specific property naming into a single canonical schema, enabling one detection engine to operate across Terraform, CloudFormation, and Pulumi simultaneously. This has not been done before in published research or open source tooling.

---

## 3. Two-Phase Architecture Overview

### Phase 1: Dissertation Version

**Goal:** Prove the concept. Run the controlled experiment. Submit the dissertation.

**Package:** Python only. `pip install driftfinder`. Targets Python 3.11+.

**Scope:**
- Three IaC tools: Terraform, CloudFormation (and CDK), Pulumi
- Eight AWS resource types: S3 Bucket, Security Group, IAM Policy, RDS Instance, EBS Volume, CloudTrail, VPC, KMS Key
- CIS AWS Foundations Benchmark v3.0 controls applicable to those eight types
- CLI with init, scan, schedule, unschedule, report commands
- JSON and HTML output
- Exponential backoff for AWS API rate limiting
- Scheduled cron mode for continuous monitoring between deployments
- Basic CI/CD integration via exit codes

**Must NOT include in Phase 1:**
- TypeScript SDK
- AI fix suggestions
- Slack notifications
- MCP server
- Remediation mode (driftfinder remediate)
- Multi-threading or async beyond what Boto3 handles natively
- All 58 CIS controls (only those applicable to the 8 resource types)

### Phase 2: Full Production Version

**Goal:** Ship a production-grade tool the DevSecOps community actually adopts.

**Adds to Phase 1:**
- TypeScript/JavaScript SDK (`@driftfinder/sdk`) published to npm
- All 58 CIS AWS Foundations Benchmark v3.0 controls
- asyncio + ProcessPoolExecutor for concurrent scanning
- Token bucket rate limiting
- Jittered exponential backoff via tenacity
- Immutable NRM enforcement (frozen dataclasses)
- State-file locking via DynamoDB or Redis mutexes
- Dependency graph (DAG) for safe remediation ordering
- driftfinder remediate command (idempotent)
- AI fix suggestions (--ai-fix, --ai-explain) via Anthropic/OpenAI
- Slack webhook notifications
- MCP server (driftfinder mcp-server)
- Plugin architecture for GCP and Azure adapters (community contribution targets)
- SBOM generation via CycloneDX
- Signed releases via sigstore/cosign

---

## 4. Repository Structure

```
driftfinder/
├── .github/
│   ├── workflows/
│   │   ├── ci.yml                    # Run on every PR: test, lint, type-check, security
│   │   ├── release.yml               # Run on tag: build, publish to PyPI and npm
│   │   └── security.yml              # Weekly: dependency scan, CodeQL
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   └── feature_request.md
│   └── PULL_REQUEST_TEMPLATE.md
│
├── docs/
│   ├── adr/                          # Architecture Decision Records
│   │   ├── 001-python-first.md
│   │   ├── 002-nrm-design.md
│   │   └── 003-pydantic-models.md
│   ├── api/                          # Auto-generated API docs
│   └── contributing.md
│
├── src/
│   └── driftfinder/
│       ├── __init__.py               # Version, public API exports
│       ├── py.typed                  # PEP 561 marker
│       │
│       ├── cli/
│       │   ├── __init__.py
│       │   ├── main.py               # Click group, entry point
│       │   └── commands/
│       │       ├── __init__.py
│       │       ├── init.py           # driftfinder init
│       │       ├── scan.py           # driftfinder scan
│       │       ├── schedule.py       # driftfinder schedule
│       │       ├── unschedule.py     # driftfinder unschedule
│       │       └── report.py         # driftfinder report
│       │
│       ├── core/
│       │   ├── __init__.py
│       │   ├── engine.py             # Orchestrates parsers, runtime, detection
│       │   └── config.py             # Config model, reads .driftfinder.yml
│       │
│       ├── models/
│       │   ├── __init__.py
│       │   ├── nrm.py                # All NRM dataclass definitions
│       │   ├── findings.py           # DriftFinding, ScanResult models
│       │   └── enums.py              # DriftType, Severity, IaCTool enums
│       │
│       ├── parsers/
│       │   ├── __init__.py
│       │   ├── base.py               # Abstract base parser
│       │   ├── terraform.py          # Reads .tfstate JSON
│       │   ├── cloudformation.py     # Reads CF stack via AWS API
│       │   └── pulumi.py             # Reads pulumi stack export JSON
│       │
│       ├── runtime/
│       │   ├── __init__.py
│       │   ├── base.py               # Abstract base runtime querier
│       │   ├── client.py             # Boto3 session factory with retry config
│       │   └── aws/
│       │       ├── __init__.py
│       │       ├── s3.py             # S3 bucket runtime queries
│       │       ├── security_group.py # EC2 security group runtime queries
│       │       ├── iam.py            # IAM policy runtime queries
│       │       ├── rds.py            # RDS instance runtime queries
│       │       ├── ebs.py            # EBS volume runtime queries
│       │       ├── cloudtrail.py     # CloudTrail runtime queries
│       │       ├── vpc.py            # VPC runtime queries
│       │       └── kms.py            # KMS key runtime queries
│       │
│       ├── mappers/
│       │   ├── __init__.py
│       │   ├── cis_mapper.py         # Maps NRM property to CIS control + severity
│       │   └── cis_mappings.py       # Complete mapping table as typed dict
│       │
│       ├── reporters/
│       │   ├── __init__.py
│       │   ├── json_reporter.py      # Produces structured JSON output
│       │   └── html_reporter.py      # Produces audit-ready HTML report
│       │
│       ├── scheduler/
│       │   ├── __init__.py
│       │   └── cron.py               # Writes/reads/removes crontab entries
│       │
│       └── utils/
│           ├── __init__.py
│           ├── retry.py              # Exponential backoff utilities
│           └── logging.py            # Structured logging setup
│
├── tests/
│   ├── __init__.py
│   ├── conftest.py                   # Shared fixtures, LocalStack setup
│   ├── fixtures/
│   │   ├── tfstate/                  # Sample .tfstate files for testing
│   │   │   ├── s3_compliant.json
│   │   │   ├── s3_drifted.json
│   │   │   ├── security_group_compliant.json
│   │   │   └── ...
│   │   ├── cloudformation/           # Sample CF templates for testing
│   │   └── pulumi/                   # Sample Pulumi state files for testing
│   │
│   ├── unit/
│   │   ├── __init__.py
│   │   ├── models/
│   │   │   ├── test_nrm.py
│   │   │   └── test_findings.py
│   │   ├── parsers/
│   │   │   ├── test_terraform.py
│   │   │   ├── test_cloudformation.py
│   │   │   └── test_pulumi.py
│   │   ├── runtime/
│   │   │   ├── test_s3.py
│   │   │   ├── test_security_group.py
│   │   │   ├── test_iam.py
│   │   │   ├── test_rds.py
│   │   │   ├── test_ebs.py
│   │   │   ├── test_cloudtrail.py
│   │   │   ├── test_vpc.py
│   │   │   └── test_kms.py
│   │   ├── mappers/
│   │   │   └── test_cis_mapper.py
│   │   └── core/
│   │       └── test_engine.py
│   │
│   ├── integration/
│   │   ├── __init__.py
│   │   ├── test_drift_detection.py   # Full scan with mocked AWS, known drift
│   │   ├── test_no_drift.py          # Full scan with mocked AWS, clean state
│   │   └── test_cli.py               # CLI command integration tests
│   │
│   └── e2e/
│       ├── __init__.py
│       └── test_localstack.py        # Full scan against LocalStack
│
├── scripts/
│   ├── setup_localstack.sh           # Bootstrap LocalStack for e2e tests
│   └── generate_fixtures.py          # Generate test fixture files
│
├── CHANGELOG.md
├── CONTRIBUTING.md
├── SECURITY.md
├── LICENSE                           # Apache 2.0
├── README.md
├── pyproject.toml                    # Build config, dependencies, tool config
├── .pre-commit-config.yaml           # Pre-commit hooks
├── .driftfinder.yml.example          # Example config file
└── docker-compose.yml                # LocalStack for local e2e testing
```

---

## 5. Technology Stack

### Phase 1 (Python)

| Concern | Choice | Reason |
|---|---|---|
| Python version | 3.11+ | Modern typing features, performance improvements |
| CLI framework | Click 8.x | Industry standard, clean API, testable |
| Data models | Pydantic v2 | Runtime validation, serialisation, type safety |
| NRM objects | Python dataclasses with frozen=True | Immutability guaranteed, hashable |
| AWS SDK | Boto3 1.34+ | Official AWS SDK, full API coverage |
| AWS retry handling | botocore retry config + tenacity | Jittered exponential backoff |
| Configuration file | PyYAML | .driftfinder.yml config file |
| HTML templating | Jinja2 | Audit report generation |
| Testing | pytest 7.x | Industry standard |
| Test coverage | pytest-cov | Coverage measurement |
| AWS mocking | moto 4.x | Mock Boto3 calls in unit/integration tests |
| E2E AWS simulation | LocalStack | Full AWS API simulation locally |
| Linting | ruff | Fast, comprehensive |
| Type checking | mypy strict | Full type safety |
| Formatting | black | Consistent style |
| Import sorting | isort | Consistent imports |
| Pre-commit | pre-commit | Enforce quality before commit |
| Dependency scanning | pip-audit | Security vulnerability scanning |
| Build system | hatch | Modern Python packaging |
| Changelog | Keep a Changelog format | Human-readable changelog |

### Phase 2 additions (TypeScript SDK)

| Concern | Choice | Reason |
|---|---|---|
| Runtime | Node.js 20 LTS | LTS stability |
| Language | TypeScript 5.x strict | Type safety, developer experience |
| AWS SDK | AWS SDK v3 for JavaScript | Modular, tree-shakeable |
| Testing | Jest + ts-jest | TypeScript-native testing |
| Linting | ESLint + typescript-eslint | TypeScript-aware linting |
| Formatting | Prettier | Consistent style |
| Build | tsup | Fast TypeScript bundler |
| Concurrency | Worker Threads (Node built-in) | CPU-bound parsing isolation |
| Rate limiting | Custom token bucket | Precise AWS API rate control |
| Retry | async-retry | Jittered exponential backoff |

---

## 6. The Normalised Resource Model (NRM) — Complete Specification

The NRM is the core intellectual contribution of DriftFinder. It defines a canonical, tool-agnostic schema for every security-relevant property across all monitored resource types.

### Design principles

1. Every NRM object is immutable (frozen=True on dataclasses)
2. Every property has a canonical name that never changes regardless of IaC tool
3. Every property maps to at least one CIS control
4. Absence of a declared property in the IaC source is treated as None, NOT as the AWS default
5. The NRM schema is versioned. Changes to property names are breaking changes.

### Implementation pattern

```python
# src/driftfinder/models/nrm.py

from dataclasses import dataclass, field
from typing import Optional, TypeAlias
from enum import Enum


class EncryptionAlgorithm(str, Enum):
    NONE = "NONE"
    AES256 = "AES256"
    AWS_KMS = "aws:kms"


@dataclass(frozen=True)
class NRMBase:
    """Base class for all NRM resource models."""
    resource_id: str
    resource_name: str
    iac_tool: str  # terraform | cloudformation | pulumi
    region: str
    account_id: str = ""  # Not compared during drift detection; engine populates via STS


@dataclass(frozen=True)
class NRMS3Bucket(NRMBase):
    server_side_encryption_enabled: Optional[bool] = None
    encryption_algorithm: Optional[EncryptionAlgorithm] = None
    public_access_block_enabled: Optional[bool] = None
    block_public_acls: Optional[bool] = None
    ignore_public_acls: Optional[bool] = None
    block_public_policy: Optional[bool] = None
    restrict_public_buckets: Optional[bool] = None
    versioning_enabled: Optional[bool] = None
    mfa_delete_enabled: Optional[bool] = None
    access_logging_enabled: Optional[bool] = None
    ssl_requests_only: Optional[bool] = None


@dataclass(frozen=True)
class NRMSecurityGroup(NRMBase):
    unrestricted_ssh_ingress: Optional[bool] = None       # Port 22, 0.0.0.0/0 or ::/0
    unrestricted_rdp_ingress: Optional[bool] = None       # Port 3389, 0.0.0.0/0 or ::/0
    unrestricted_all_traffic_ingress: Optional[bool] = None  # Protocol -1, 0.0.0.0/0
    unrestricted_all_traffic_egress: Optional[bool] = None
    egress_restricted: Optional[bool] = None
    ingress_rules: Optional[tuple] = None                 # tuple (not list) — frozen dataclasses must be hashable
    egress_rules: Optional[tuple] = None                  # tuple (not list) — frozen dataclasses must be hashable


@dataclass(frozen=True)
class NRMIAMPolicy(NRMBase):
    has_wildcard_action: Optional[bool] = None            # Action: *
    has_wildcard_resource: Optional[bool] = None          # Resource: * with broad actions
    has_admin_access: Optional[bool] = None               # AdministratorAccess equivalent
    has_explicit_deny: Optional[bool] = None
    policy_document_hash: Optional[str] = None            # SHA256 of policy JSON for change detection


@dataclass(frozen=True)
class NRMRDSInstance(NRMBase):
    storage_encrypted: Optional[bool] = None
    publicly_accessible: Optional[bool] = None            # Should be False
    backup_retention_days: Optional[int] = None           # Should be > 0
    deletion_protection: Optional[bool] = None
    multi_az: Optional[bool] = None
    auto_minor_version_upgrade: Optional[bool] = None


@dataclass(frozen=True)
class NRMEBSVolume(NRMBase):
    encrypted: Optional[bool] = None
    delete_on_termination: Optional[bool] = None
    snapshot_encrypted: Optional[bool] = None


@dataclass(frozen=True)
class NRMCloudTrail(NRMBase):
    multi_region_enabled: Optional[bool] = None
    log_file_validation_enabled: Optional[bool] = None
    cloudwatch_logs_enabled: Optional[bool] = None
    s3_bucket_logging_enabled: Optional[bool] = None
    kms_encryption_enabled: Optional[bool] = None
    is_logging: Optional[bool] = None                     # Trail is actively logging


@dataclass(frozen=True)
class NRMVPC(NRMBase):
    flow_logs_enabled: Optional[bool] = None
    default_sg_has_no_rules: Optional[bool] = None        # Default SG should have no rules
    nacl_unrestricted_ingress: Optional[bool] = None


@dataclass(frozen=True)
class NRMKMSKey(NRMBase):
    key_rotation_enabled: Optional[bool] = None
    key_enabled: Optional[bool] = None                    # KeyState == Enabled
    key_policy_allows_public_access: Optional[bool] = None


# Union type for all NRM resource types
NRMResource: TypeAlias = (
    NRMS3Bucket |
    NRMSecurityGroup |
    NRMIAMPolicy |
    NRMRDSInstance |
    NRMEBSVolume |
    NRMCloudTrail |
    NRMVPC |
    NRMKMSKey
)
```

### NRM property rules

**None vs False:**
None means "this property was not declared in the IaC source or could not be determined."
False means "this property was explicitly declared as false or absent."
This distinction matters for detecting when an IaC tool omits a property (which may use AWS defaults) versus explicitly setting it to a non-compliant value.

**AWS defaults handling:**
CloudFormation templates often omit properties that have AWS default values. When a property is None in the declared NRM but has a known AWS default that would be non-compliant, this should be flagged as a WARNING drift type, not MODIFIED, to distinguish it from an explicit change. Document this behaviour clearly in the code.

---

## 7. AWS API Mappings — Complete Specification

This section defines the exact Boto3 API calls required for each resource type and how the responses map to NRM properties. This is the contract for the Runtime State Query Engine.

### 7.1 S3 Bucket

```python
# Required API calls per bucket:

# 1. Encryption
response = s3.get_bucket_encryption(Bucket=bucket_name)
# Maps to:
# server_side_encryption_enabled = True if Rules exist and non-empty
# encryption_algorithm = Rules[0].ApplyServerSideEncryptionByDefault.SSEAlgorithm
# Handle NoSuchConfiguration exception -> server_side_encryption_enabled = False

# 2. Public access block
response = s3.get_public_access_block(Bucket=bucket_name)
# Maps to:
# block_public_acls = PublicAccessBlockConfiguration.BlockPublicAcls
# ignore_public_acls = PublicAccessBlockConfiguration.IgnorePublicAcls
# block_public_policy = PublicAccessBlockConfiguration.BlockPublicPolicy
# restrict_public_buckets = PublicAccessBlockConfiguration.RestrictPublicBuckets
# public_access_block_enabled = all four are True
# Handle NoSuchPublicAccessBlockConfiguration -> all False

# 3. Versioning
response = s3.get_bucket_versioning(Bucket=bucket_name)
# Maps to:
# versioning_enabled = Status == "Enabled"
# mfa_delete_enabled = MFADelete == "Enabled"

# 4. Logging
response = s3.get_bucket_logging(Bucket=bucket_name)
# Maps to:
# access_logging_enabled = "LoggingEnabled" in response

# 5. Policy for SSL-only check
try:
    response = s3.get_bucket_policy(Bucket=bucket_name)
    # Parse policy JSON to check for aws:SecureTransport condition
except s3.exceptions.NoSuchBucketPolicy:
    ssl_requests_only = False
```

### 7.2 Security Group

```python
# Required API calls:

# 1. Describe security group
response = ec2.describe_security_groups(GroupIds=[sg_id])
sg = response['SecurityGroups'][0]

# Maps to:
# ingress_rules = sg['IpPermissions']
# egress_rules = sg['IpPermissionsEgress']

# Derived properties (computed from rules):
def has_unrestricted_ssh(ingress_rules):
    for rule in ingress_rules:
        if rule.get('FromPort') == 22 and rule.get('ToPort') == 22:
            for ip_range in rule.get('IpRanges', []):
                if ip_range.get('CidrIp') == '0.0.0.0/0':
                    return True
            for ip_range in rule.get('Ipv6Ranges', []):
                if ip_range.get('CidrIpv6') == '::/0':
                    return True
    return False

# Same pattern for RDP (port 3389)
# Same pattern for unrestricted_all_traffic (IpProtocol == '-1')
```

### 7.3 IAM Policy

```python
# Required API calls:

# 1. Get policy version (for managed policies)
# First get the default version ID
response = iam.get_policy(PolicyArn=policy_arn)
default_version = response['Policy']['DefaultVersionId']

# Then get the policy document
response = iam.get_policy_version(
    PolicyArn=policy_arn,
    VersionId=default_version
)
policy_doc = response['PolicyVersion']['Document']

# For inline policies attached to roles/users/groups
response = iam.get_role_policy(RoleName=role_name, PolicyName=policy_name)
policy_doc = response['PolicyDocument']

# Derived properties:
def has_wildcard_action(policy_doc):
    for statement in policy_doc.get('Statement', []):
        if statement.get('Effect') == 'Allow':
            actions = statement.get('Action', [])
            if isinstance(actions, str):
                actions = [actions]
            if '*' in actions:
                return True
    return False

def has_wildcard_resource(policy_doc):
    for statement in policy_doc.get('Statement', []):
        if statement.get('Effect') == 'Allow':
            resources = statement.get('Resource', [])
            if isinstance(resources, str):
                resources = [resources]
            if '*' in resources:
                return True
    return False

def has_explicit_deny(policy_doc):
    for statement in policy_doc.get('Statement', []):
        if statement.get('Effect') == 'Deny':
            return True
    return False
```

### 7.4 RDS Instance

```python
# Required API calls:

response = rds.describe_db_instances(DBInstanceIdentifier=db_id)
db = response['DBInstances'][0]

# Maps to:
# storage_encrypted = db['StorageEncrypted']
# publicly_accessible = db['PubliclyAccessible']
# backup_retention_days = db['BackupRetentionPeriod']
# deletion_protection = db['DeletionProtection']
# multi_az = db['MultiAZ']
# auto_minor_version_upgrade = db['AutoMinorVersionUpgrade']
```

### 7.5 EBS Volume

```python
# Required API calls:

response = ec2.describe_volumes(VolumeIds=[volume_id])
volume = response['Volumes'][0]

# Maps to:
# encrypted = volume['Encrypted']

# For delete_on_termination, check the attachment
if volume.get('Attachments'):
    delete_on_termination = volume['Attachments'][0].get('DeleteOnTermination', False)
else:
    delete_on_termination = None  # Not attached, cannot determine

# For snapshots (check most recent snapshot)
response = ec2.describe_snapshots(Filters=[
    {'Name': 'volume-id', 'Values': [volume_id]}
])
# snapshot_encrypted = any(s['Encrypted'] for s in snapshots) if snapshots else None
```

### 7.6 CloudTrail

```python
# Required API calls:

# 1. Get trail info
response = cloudtrail.describe_trails(includeShadowTrails=False)
trails = response['trailList']

# For each trail:
# multi_region_enabled = trail['IsMultiRegionTrail']
# log_file_validation_enabled = trail['LogFileValidationEnabled']
# kms_encryption_enabled = 'KMSKeyId' in trail and trail['KMSKeyId'] is not None

# 2. Get trail status (is it actively logging?)
response = cloudtrail.get_trail_status(Name=trail_arn)
# is_logging = response['IsLogging']

# 3. CloudWatch Logs integration
# cloudwatch_logs_enabled = 'CloudWatchLogsLogGroupArn' in trail and trail['CloudWatchLogsLogGroupArn'] is not None
```

### 7.7 VPC

```python
# Required API calls:

# 1. Describe VPC
response = ec2.describe_vpcs(VpcIds=[vpc_id])
vpc = response['Vpcs'][0]

# 2. Flow logs
response = ec2.describe_flow_logs(
    Filters=[{'Name': 'resource-id', 'Values': [vpc_id]}]
)
# flow_logs_enabled = len(response['FlowLogs']) > 0 and any(fl['FlowLogStatus'] == 'ACTIVE' for fl in response['FlowLogs'])

# 3. Default security group for this VPC
response = ec2.describe_security_groups(
    Filters=[
        {'Name': 'vpc-id', 'Values': [vpc_id]},
        {'Name': 'group-name', 'Values': ['default']}
    ]
)
if response['SecurityGroups']:
    default_sg = response['SecurityGroups'][0]
    # default_sg_has_no_rules = (
    #     len(default_sg.get('IpPermissions', [])) == 0 and
    #     len(default_sg.get('IpPermissionsEgress', [])) == 0
    # )

# 4. Network ACLs
response = ec2.describe_network_acls(
    Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}]
)
# Check for any entry that allows all traffic from 0.0.0.0/0
```

### 7.8 KMS Key

```python
# Required API calls:

# 1. Key metadata
response = kms.describe_key(KeyId=key_id)
metadata = response['KeyMetadata']
# key_enabled = metadata['KeyState'] == 'Enabled'
# Only check rotation for symmetric keys (KeySpec == 'SYMMETRIC_DEFAULT')

# 2. Key rotation status (only for symmetric keys)
if metadata.get('KeySpec') == 'SYMMETRIC_DEFAULT' and metadata.get('KeyManager') == 'CUSTOMER':
    response = kms.get_key_rotation_status(KeyId=key_id)
    # key_rotation_enabled = response['KeyRotationEnabled']
else:
    # AWS-managed keys handle rotation automatically
    # key_rotation_enabled = None (not applicable)

# 3. Key policy
response = kms.get_key_policy(KeyId=key_id, PolicyName='default')
policy_doc = json.loads(response['Policy'])
# Check for Principal: * which allows public access
```

---

## 8. CIS Control Mappings — Complete Specification

This is the complete mapping table from NRM property to CIS AWS Foundations Benchmark v3.0 control ID and severity. This drives the CIS Compliance Mapper.

```python
# src/driftfinder/mappers/cis_mappings.py

from typing import NamedTuple
from driftfinder.models.enums import Severity


class CISControl(NamedTuple):
    control_id: str
    description: str
    severity: Severity


# Key format: "ResourceType.property_name"
CIS_MAPPINGS: dict[str, CISControl] = {

    # S3 Bucket
    "NRMS3Bucket.server_side_encryption_enabled": CISControl(
        "2.1.1",
        "Ensure all S3 buckets employ encryption-at-rest",
        Severity.HIGH
    ),
    "NRMS3Bucket.encryption_algorithm": CISControl(
        "2.1.1",
        "Ensure all S3 buckets employ encryption-at-rest",
        Severity.HIGH
    ),
    "NRMS3Bucket.public_access_block_enabled": CISControl(
        "2.1.4",
        "Ensure that S3 Buckets are configured with Block Public Access",
        Severity.CRITICAL
    ),
    "NRMS3Bucket.block_public_acls": CISControl(
        "2.1.4",
        "Ensure that S3 Buckets are configured with Block Public Access (BlockPublicAcls)",
        Severity.CRITICAL
    ),
    "NRMS3Bucket.ignore_public_acls": CISControl(
        "2.1.4",
        "Ensure that S3 Buckets are configured with Block Public Access (IgnorePublicAcls)",
        Severity.CRITICAL
    ),
    "NRMS3Bucket.block_public_policy": CISControl(
        "2.1.4",
        "Ensure that S3 Buckets are configured with Block Public Access (BlockPublicPolicy)",
        Severity.CRITICAL
    ),
    "NRMS3Bucket.restrict_public_buckets": CISControl(
        "2.1.4",
        "Ensure that S3 Buckets are configured with Block Public Access (RestrictPublicBuckets)",
        Severity.CRITICAL
    ),
    "NRMS3Bucket.versioning_enabled": CISControl(
        "2.1.2",
        "Ensure MFA Delete is enabled on S3 buckets",
        Severity.MEDIUM
    ),
    "NRMS3Bucket.mfa_delete_enabled": CISControl(
        "2.1.2",
        "Ensure MFA Delete is enabled on S3 buckets",
        Severity.HIGH
    ),
    "NRMS3Bucket.access_logging_enabled": CISControl(
        "2.1.5",
        "Ensure that S3 Buckets have Object-level logging enabled with CloudTrail",
        Severity.MEDIUM
    ),
    "NRMS3Bucket.ssl_requests_only": CISControl(
        "2.1.1",
        "Ensure S3 bucket policy requires SSL",
        Severity.HIGH
    ),

    # Security Group
    "NRMSecurityGroup.unrestricted_ssh_ingress": CISControl(
        "5.2",
        "Ensure no security groups allow ingress from 0.0.0.0/0 to port 22",
        Severity.CRITICAL
    ),
    "NRMSecurityGroup.unrestricted_rdp_ingress": CISControl(
        "5.3",
        "Ensure no security groups allow ingress from 0.0.0.0/0 to port 3389",
        Severity.CRITICAL
    ),
    "NRMSecurityGroup.unrestricted_all_traffic_ingress": CISControl(
        "5.4",
        "Ensure no security groups allow unrestricted access",
        Severity.CRITICAL
    ),

    # IAM Policy
    "NRMIAMPolicy.has_wildcard_action": CISControl(
        "1.16",
        "Ensure IAM policies that allow full administrative privileges are not attached",
        Severity.CRITICAL
    ),
    "NRMIAMPolicy.has_wildcard_resource": CISControl(
        "1.16",
        "Ensure IAM policies that allow full administrative privileges are not attached",
        Severity.HIGH
    ),
    "NRMIAMPolicy.has_admin_access": CISControl(
        "1.16",
        "Ensure IAM policies that allow full administrative privileges are not attached",
        Severity.HIGH
    ),

    # RDS Instance
    "NRMRDSInstance.storage_encrypted": CISControl(
        "2.3.1",
        "Ensure that encryption-at-rest is enabled for RDS Instances",
        Severity.CRITICAL
    ),
    "NRMRDSInstance.publicly_accessible": CISControl(
        "2.3.2",
        "Ensure that public access is not given to RDS Instance",
        Severity.HIGH
    ),
    "NRMRDSInstance.backup_retention_days": CISControl(
        "2.3.3",
        "Ensure that RDS clusters have backup enabled",
        Severity.MEDIUM
    ),

    # EBS Volume
    "NRMEBSVolume.encrypted": CISControl(
        "2.2.1",
        "Ensure EBS Volume Encryption is Enabled in all Regions",
        Severity.CRITICAL
    ),

    # CloudTrail
    "NRMCloudTrail.multi_region_enabled": CISControl(
        "3.1",
        "Ensure CloudTrail is enabled in all regions",
        Severity.HIGH
    ),
    "NRMCloudTrail.log_file_validation_enabled": CISControl(
        "3.2",
        "Ensure CloudTrail log file validation is enabled",
        Severity.HIGH
    ),
    "NRMCloudTrail.cloudwatch_logs_enabled": CISControl(
        "3.4",
        "Ensure CloudTrail trails are integrated with CloudWatch Logs",
        Severity.MEDIUM
    ),
    "NRMCloudTrail.kms_encryption_enabled": CISControl(
        "3.7",
        "Ensure CloudTrail logs are encrypted at rest using KMS CMKs",
        Severity.HIGH
    ),
    "NRMCloudTrail.is_logging": CISControl(
        "3.1",
        "Ensure CloudTrail is actively logging",
        Severity.CRITICAL
    ),

    # VPC
    "NRMVPC.flow_logs_enabled": CISControl(
        "5.1",
        "Ensure VPC flow logging is enabled in all VPCs",
        Severity.HIGH
    ),
    "NRMVPC.default_sg_has_no_rules": CISControl(
        "5.5",
        "Ensure the default security group of every VPC restricts all traffic",
        Severity.CRITICAL
    ),

    # KMS Key
    "NRMKMSKey.key_rotation_enabled": CISControl(
        "3.7",
        "Ensure rotation for customer-created symmetric CMKs is enabled",
        Severity.HIGH
    ),
    "NRMKMSKey.key_enabled": CISControl(
        "3.7",
        "Ensure KMS key is not disabled",
        Severity.CRITICAL
    ),
    "NRMKMSKey.key_policy_allows_public_access": CISControl(
        "3.7",
        "Ensure KMS key policy does not allow public access",
        Severity.HIGH
    ),
}
```

---

## 9. IaC Parser Specifications

### 9.1 Base Parser Interface

```python
# src/driftfinder/parsers/base.py

from abc import ABC, abstractmethod
from typing import Iterator
from driftfinder.models.nrm import NRMResource


class BaseParser(ABC):
    """
    Abstract base class for all IaC parsers.
    Each parser must implement parse() and yield NRM resource objects.
    """

    @abstractmethod
    def parse(self, source: str, **kwargs) -> Iterator[NRMResource]:
        """
        Parse the IaC state source and yield normalised resource objects.

        Args:
            source: Path to state file, stack name, or state export JSON string
            **kwargs: Parser-specific options

        Yields:
            NRMResource objects with declared property values populated
        """
        ...

    @abstractmethod
    def supports_resource_type(self, resource_type: str) -> bool:
        """Return True if this parser can handle the given AWS resource type."""
        ...
```

### 9.2 Terraform Parser

The Terraform parser reads the `.tfstate` JSON file. Terraform state files follow a versioned schema. DriftFinder targets schema version 4, which is current.

```
State file structure:
{
  "version": 4,
  "terraform_version": "...",
  "resources": [
    {
      "mode": "managed",
      "type": "aws_s3_bucket",
      "name": "example",
      "provider": "provider[\"registry.terraform.io/hashicorp/aws\"]",
      "instances": [
        {
          "schema_version": 0,
          "attributes": {
            "id": "my-bucket-name",
            "bucket": "my-bucket-name",
            ...
          }
        }
      ]
    }
  ]
}
```

**Key Terraform resource type to NRM mapping:**

| Terraform type | NRM class |
|---|---|
| aws_s3_bucket | NRMS3Bucket |
| aws_s3_bucket_server_side_encryption_configuration | Supplement NRMS3Bucket |
| aws_s3_bucket_public_access_block | Supplement NRMS3Bucket |
| aws_security_group | NRMSecurityGroup |
| aws_iam_policy | NRMIAMPolicy |
| aws_iam_role_policy | NRMIAMPolicy |
| aws_db_instance | NRMRDSInstance |
| aws_ebs_volume | NRMEBSVolume |
| aws_cloudtrail | NRMCloudTrail |
| aws_vpc | NRMVPC |
| aws_kms_key | NRMKMSKey |

**Important Terraform-specific note:**
In Terraform AWS provider v4+, S3 bucket properties were split into separate resources (aws_s3_bucket_server_side_encryption_configuration, aws_s3_bucket_public_access_block, etc.). The parser must handle both the legacy monolithic aws_s3_bucket format and the modern split format. When building the NRM, merge properties from the parent bucket resource and all associated supplementary resources with the same bucket ID.

**Terraform property paths for S3:**
```
Encryption (legacy format):
attributes.server_side_encryption_configuration[0].rule[0].apply_server_side_encryption_by_default[0].sse_algorithm

Encryption (modern format, separate resource):
aws_s3_bucket_server_side_encryption_configuration attributes:
  rule[0].apply_server_side_encryption_by_default[0].sse_algorithm

Public access block (separate resource):
aws_s3_bucket_public_access_block attributes:
  block_public_acls
  block_public_policy
  ignore_public_acls
  restrict_public_buckets
```

### 9.3 CloudFormation Parser

The CloudFormation parser uses two AWS API calls to reconstruct the declared state.

```python
# Call 1: Get the template (declared intent)
response = cfn.get_template(StackName=stack_name, TemplateStage='Original')
template = yaml.safe_load(response['TemplateBody'])  # Handle both JSON and YAML

# Call 2: Get the physical resource IDs
response = cfn.describe_stack_resources(StackName=stack_name)
resources = {r['LogicalResourceId']: r['PhysicalResourceId'] for r in response['StackResources']}
```

**Important CloudFormation-specific note:**
CloudFormation templates often omit properties that take AWS default values. For example, `ServerSideEncryptionConfiguration` may be absent from the template even though the developer intended it to be encrypted because they were relying on an account-level default. When a property is absent from the template, set it to None in the NRM, NOT False. Document this in the finding if it results in a drift detection. See Section 6 NRM design principles.

**CloudFormation resource type mapping:**

| CF type | NRM class |
|---|---|
| AWS::S3::Bucket | NRMS3Bucket |
| AWS::EC2::SecurityGroup | NRMSecurityGroup |
| AWS::IAM::ManagedPolicy | NRMIAMPolicy |
| AWS::IAM::Policy | NRMIAMPolicy |
| AWS::RDS::DBInstance | NRMRDSInstance |
| AWS::EC2::Volume | NRMEBSVolume |
| AWS::CloudTrail::Trail | NRMCloudTrail |
| AWS::EC2::VPC | NRMVPC |
| AWS::KMS::Key | NRMKMSKey |

### 9.4 Pulumi Parser

The Pulumi parser reads the JSON output of `pulumi stack export`. The state file structure uses resource URNs as identifiers.

```
Pulumi state structure:
{
  "version": 3,
  "deployment": {
    "resources": [
      {
        "urn": "urn:pulumi:prod::my-project::aws:s3/bucket:Bucket::my-bucket",
        "type": "aws:s3/bucket:Bucket",
        "inputs": { ... },    // What was declared
        "outputs": { ... }    // What was actually created (use this)
      }
    ]
  }
}
```

**Important Pulumi-specific note:**
Use the `outputs` object, not `inputs`, for the declared state. The outputs represent what Pulumi actually provisioned and recorded. Inputs may contain computed values that were not yet resolved at plan time.

**Pulumi type mapping:**

| Pulumi type | NRM class |
|---|---|
| aws:s3/bucket:Bucket | NRMS3Bucket |
| aws:ec2/securityGroup:SecurityGroup | NRMSecurityGroup |
| aws:iam/policy:Policy | NRMIAMPolicy |
| aws:rds/instance:Instance | NRMRDSInstance |
| aws:ebs/volume:Volume | NRMEBSVolume |
| aws:cloudtrail/trail:Trail | NRMCloudTrail |
| aws:ec2/vpc:Vpc | NRMVPC |
| aws:kms/key:Key | NRMKMSKey |

---

## 10. Phase 1 — Dissertation Version (BUILD THIS FIRST)

### 10.1 Core Engine

```python
# src/driftfinder/core/engine.py

class DriftFinderEngine:
    """
    Orchestrates the four-layer detection pipeline.
    
    Layer 1: IaC Parser -> declared NRM objects
    Layer 2: NRM (the schema itself, applied during parsing)
    Layer 3: Runtime Query Engine -> actual NRM objects
    Layer 4: Drift Detection + CIS Mapping -> DriftFindings
    """
    
    def __init__(self, config: DriftFinderConfig):
        self.config = config
        self.parser = self._get_parser(config.iac_tool)
        self.runtime = AWSRuntimeQuerier(config)
        self.cis_mapper = CISMapper()
    
    def scan(self) -> ScanResult:
        """
        Run a complete drift detection scan.
        
        Returns:
            ScanResult containing all findings, scan metadata, and summary
        """
        # Step 1: Parse declared state
        declared_resources = list(self.parser.parse(self.config.state_source))
        
        # Step 2: Query runtime state for same resources
        actual_resources = [
            self.runtime.query(resource) 
            for resource in declared_resources
        ]
        
        # Step 3: Detect drift
        findings = []
        for declared, actual in zip(declared_resources, actual_resources):
            resource_findings = self._detect_drift(declared, actual)
            findings.extend(resource_findings)
        
        # Step 4: Return scan result
        return ScanResult(
            findings=findings,
            scan_timestamp=datetime.utcnow(),
            iac_tool=self.config.iac_tool,
            resources_scanned=len(declared_resources),
            resources_with_drift=len(set(f.resource_id for f in findings)),
            compliant=len(findings) == 0
        )
    
    def _detect_drift(self, declared: NRMResource, actual: NRMResource) -> list[DriftFinding]:
        """
        Compare declared and actual NRM objects property by property.
        Implements: Drift(s) = {p ∈ P(s) | D(s)[p] ≠ A(s)[p]}
        """
        findings = []
        
        # Get all fields defined in the NRM dataclass
        for field_name in declared.__dataclass_fields__:
            if field_name in ('resource_id', 'resource_name', 'iac_tool', 'region', 'account_id'):
                continue  # Skip metadata fields
            
            declared_value = getattr(declared, field_name)
            actual_value = getattr(actual, field_name)
            
            # None in declared means not specified in IaC - do not flag as drift
            # unless actual value is None too (cannot determine)
            if declared_value is None:
                continue
            
            if declared_value != actual_value:
                cis_control = self.cis_mapper.get_control(
                    type(declared).__name__, 
                    field_name
                )
                
                finding = DriftFinding(
                    resource_type=type(declared).__name__,
                    resource_id=declared.resource_id,
                    resource_name=declared.resource_name,
                    iac_tool=declared.iac_tool,
                    property_path=field_name,
                    declared_value=declared_value,
                    actual_value=actual_value,
                    drift_type=self._classify_drift_type(declared_value, actual_value),
                    severity=cis_control.severity if cis_control else Severity.LOW,
                    cis_controls=[cis_control.control_id] if cis_control else [],
                    cis_description=cis_control.description if cis_control else None,
                    detected_at=datetime.utcnow()
                )
                findings.append(finding)
        
        return findings
    
    def _classify_drift_type(self, declared_value, actual_value) -> DriftType:
        if declared_value is not None and actual_value is None:
            return DriftType.DELETED
        if declared_value is None and actual_value is not None:
            return DriftType.UNMANAGED
        return DriftType.MODIFIED
```

### 10.2 DriftFinding Model

```python
# src/driftfinder/models/findings.py

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Any
from pydantic import BaseModel, computed_field, ConfigDict


class DriftFinding(BaseModel):
    """
    A single detected drift instance.
    Implements the formal tuple: f = (s, p, D(s)[p], A(s)[p], τ, σ, C)
    """
    model_config = ConfigDict(frozen=True)

    resource_type: str           # s - resource type
    resource_id: str             # s - resource identifier
    resource_name: str           # s - human-readable name
    iac_tool: str                # terraform | cloudformation | pulumi
    property_path: str           # p - NRM property name
    declared_value: Any          # D(s)[p] - IaC declared value
    actual_value: Any            # A(s)[p] - AWS observed value
    drift_type: DriftType        # τ - MODIFIED | DELETED | UNMANAGED
    severity: Severity           # σ - CRITICAL | HIGH | MEDIUM | LOW
    cis_controls: list[str]      # C - CIS control IDs
    cis_description: Optional[str] = None
    detected_at: datetime = None


class ScanResult(BaseModel):
    """Complete result of a drift detection scan."""
    model_config = ConfigDict(frozen=True)

    findings: list[DriftFinding]
    scan_timestamp: datetime
    iac_tool: str
    state_source: str
    resources_scanned: int
    resources_with_drift: int
    compliant: bool
    scan_duration_seconds: float

    @computed_field  # type: ignore[misc]
    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @computed_field  # type: ignore[misc]
    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.HIGH)

    @computed_field  # type: ignore[misc]
    @property
    def medium_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.MEDIUM)

    @computed_field  # type: ignore[misc]
    @property
    def low_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.LOW)
```

### 10.3 Configuration Model

```python
# src/driftfinder/core/config.py

from pydantic import BaseModel, model_validator
from typing import Optional
from enum import Enum

CONFIG_FILE_NAME = ".driftfinder.yml"


class IaCTool(str, Enum):
    TERRAFORM = "terraform"
    CLOUDFORMATION = "cloudformation"
    PULUMI = "pulumi"


class OutputFormat(str, Enum):
    JSON = "json"
    HTML = "html"
    BOTH = "both"


class ScanMode(str, Enum):
    DEFAULT = "default"
    REPORT_ONLY = "report-only"


class FailOn(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class DriftFinderConfig(BaseModel):
    # Required
    iac_tool: IaCTool
    aws_profile: Optional[str] = None
    aws_region: str = "eu-west-2"  # Default to UK region
    
    # IaC source (one of these must be set)
    state_file: Optional[str] = None       # Terraform: path or s3://...
    stack_name: Optional[str] = None       # CloudFormation/CDK: stack name
    pulumi_stack: Optional[str] = None     # Pulumi: org/project/stack
    
    # Scan options
    output_format: OutputFormat = OutputFormat.BOTH
    output_path: Optional[str] = None
    fail_on: FailOn = FailOn.CRITICAL
    mode: ScanMode = ScanMode.DEFAULT
    
    # Retry config
    max_retries: int = 3
    retry_base_delay: float = 1.0
    retry_max_delay: float = 30.0
    
    @model_validator(mode='after')
    def at_least_one_source(self) -> 'DriftFinderConfig':
        if not any([self.state_file, self.stack_name, self.pulumi_stack]):
            raise ValueError(
                "At least one state source must be configured: "
                "state_file, stack_name, or pulumi_stack"
            )
        return self
    
    @classmethod
    def from_file(cls, path: str = CONFIG_FILE_NAME) -> "DriftFinderConfig":
        """Load config from .driftfinder.yml"""
        import yaml
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls(**data)
    
    @classmethod
    def from_env(cls) -> "DriftFinderConfig":
        """Load config from environment variables (for CI/CD)."""
        import os
        return cls(
            iac_tool=os.environ['DRIFTFINDER_TOOL'],
            aws_region=os.environ.get('AWS_DEFAULT_REGION', 'eu-west-2'),
            state_file=os.environ.get('DRIFTFINDER_STATE_FILE'),
            stack_name=os.environ.get('DRIFTFINDER_STACK_NAME'),
        )
```

### 10.4 Retry Utility

```python
# src/driftfinder/utils/retry.py

import time
import random
import functools
import logging
from typing import Callable, TypeVar, Type
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
T = TypeVar('T')

RETRYABLE_ERROR_CODES = {
    'ThrottlingException',
    'RequestLimitExceeded',
    'ServiceUnavailable',
    'InternalError',
    'RequestTimeout',
    'TooManyRequestsException',
    'Throttling',
}


def aws_retry(
    max_attempts: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    exceptions: tuple[Type[Exception], ...] = (ClientError,)
):
    """
    Decorator for AWS API calls with jittered exponential backoff.
    
    Implements: delay = min(base * 2^attempt + random(0, 1), max_delay)
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    
                    # For ClientError, only retry on throttling
                    if isinstance(e, ClientError):
                        error_code = e.response['Error']['Code']
                        if error_code not in RETRYABLE_ERROR_CODES:
                            raise
                    
                    if attempt == max_attempts - 1:
                        break
                    
                    # Jittered exponential backoff
                    delay = min(
                        base_delay * (2 ** attempt) + random.uniform(0, 1),
                        max_delay
                    )
                    
                    logger.warning(
                        f"AWS API call failed (attempt {attempt + 1}/{max_attempts}), "
                        f"retrying in {delay:.2f}s. Error: {e}"
                    )
                    time.sleep(delay)
            
            raise last_exception
        
        return wrapper
    return decorator
```

### 10.5 HTML Report Template

The HTML report must be professional enough for a PCI-DSS auditor to accept. It should include:
- DriftFinder logo/header with scan timestamp
- Summary section: total resources scanned, resources with drift, findings by severity
- Findings table: resource type, resource ID, property, declared value, actual value, severity badge, CIS control
- Colour-coded severity badges (CRITICAL=red, HIGH=orange, MEDIUM=yellow, LOW=grey)
- Export timestamp and IaC tool used
- Footer with DriftFinder version and Apache 2.0 licence

Use Jinja2 for templating. Store the template in `src/driftfinder/reporters/templates/report.html.j2`.

### 10.6 Scheduler

```python
# src/driftfinder/scheduler/cron.py

import os
import subprocess
import shutil
import sys


class CronScheduler:
    """
    Manages crontab entries for continuous scheduled scanning.
    
    Note: On Windows, this module uses Task Scheduler instead.
    The cron entry includes the full path to the driftfinder binary
    and explicitly sources the AWS credentials profile to ensure
    the cron job has the correct environment.
    """
    
    CRON_COMMENT = "# DriftFinder scheduled scan"
    
    def schedule(self, interval_minutes: int, config_path: str, output_path: str):
        """Write a crontab entry for the given interval."""
        binary_path = shutil.which('driftfinder')
        if not binary_path:
            raise RuntimeError("driftfinder binary not found in PATH")
        
        # Build cron expression
        if interval_minutes == 1:
            cron_expr = "* * * * *"
        elif interval_minutes < 60:
            cron_expr = f"*/{interval_minutes} * * * *"
        elif interval_minutes == 60:
            cron_expr = "0 * * * *"
        else:
            hours = interval_minutes // 60
            cron_expr = f"0 */{hours} * * *"
        
        # Build the command with explicit config path
        command = (
            f"{binary_path} scan "
            f"--config {config_path} "
            f"--output {output_path} "
            f"--mode report-only"  # Cron jobs never fail pipelines
        )
        
        cron_line = f"{cron_expr} {command} {self.CRON_COMMENT}"
        
        # Read existing crontab, remove any existing DriftFinder entry, add new
        current = self._read_crontab()
        cleaned = [
            line for line in current.splitlines()
            if self.CRON_COMMENT not in line
        ]
        cleaned.append(cron_line)
        self._write_crontab('\n'.join(cleaned) + '\n')
    
    def unschedule(self):
        """Remove the DriftFinder crontab entry."""
        current = self._read_crontab()
        cleaned = [
            line for line in current.splitlines()
            if self.CRON_COMMENT not in line
        ]
        self._write_crontab('\n'.join(cleaned) + '\n')
    
    def _read_crontab(self) -> str:
        result = subprocess.run(['crontab', '-l'], capture_output=True, text=True)
        return result.stdout if result.returncode == 0 else ''
    
    def _write_crontab(self, content: str):
        result = subprocess.run(['crontab', '-'], input=content, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to write crontab: {result.stderr}")
```

---

## 11. Phase 2 — Full Production Version

**DO NOT START PHASE 2 UNTIL PHASE 1 IS COMPLETE AND THE CONTROLLED EXPERIMENT HAS BEEN RUN.**

Phase 2 extends Phase 1. It does not replace it. Every Phase 1 module remains. Phase 2 adds new modules and enhances existing ones.

### 11.1 Python Async Enhancement

Replace the synchronous scan loop in engine.py with asyncio + ProcessPoolExecutor:

```python
# Phase 2 engine enhancement

import asyncio
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass


class AsyncDriftFinderEngine(DriftFinderEngine):
    """
    Phase 2: Concurrent scanning using asyncio + ProcessPoolExecutor.
    CPU-bound NRM parsing runs in separate processes.
    I/O-bound AWS API calls run concurrently via asyncio.
    """
    
    async def scan_async(self) -> ScanResult:
        loop = asyncio.get_event_loop()
        
        # Parse declared state (CPU-bound, offload to ProcessPoolExecutor)
        with ProcessPoolExecutor() as executor:
            declared_resources = await loop.run_in_executor(
                executor,
                self._parse_declared_state
            )
        
        # Query runtime state concurrently (I/O-bound, use asyncio)
        tasks = [
            self._query_runtime_async(resource)
            for resource in declared_resources
        ]
        actual_resources = await asyncio.gather(*tasks, return_exceptions=False)
        
        # Detect drift
        findings = []
        for declared, actual in zip(declared_resources, actual_resources):
            findings.extend(self._detect_drift(declared, actual))
        
        return ScanResult(findings=findings, ...)
```

### 11.2 Token Bucket Rate Limiter

```python
# Phase 2: Token bucket for AWS API rate limiting

import asyncio
import time
from dataclasses import dataclass, field


@dataclass
class TokenBucket:
    """
    Token bucket algorithm for API rate limiting.
    
    AWS service-specific rates (requests per second):
    - S3: 3500 PUT/COPY/POST/DELETE, 5500 GET/HEAD per prefix
    - EC2: 100 describe calls per second (varies by API)
    - IAM: 100 calls per second globally (LOWER - be careful)
    - RDS: 100 calls per second
    - KMS: 5500 calls per second (varies by operation)
    """
    rate: float          # Tokens per second
    capacity: float      # Maximum tokens
    tokens: float = field(init=False)
    last_refill: float = field(init=False)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock, init=False)
    
    def __post_init__(self):
        self.tokens = self.capacity
        self.last_refill = time.monotonic()
    
    async def acquire(self, tokens: float = 1.0):
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_refill
            self.tokens = min(
                self.capacity,
                self.tokens + elapsed * self.rate
            )
            self.last_refill = now
            
            if self.tokens >= tokens:
                self.tokens -= tokens
                return
            
            # Wait for enough tokens
            wait_time = (tokens - self.tokens) / self.rate
            await asyncio.sleep(wait_time)
            self.tokens = 0


# Service-specific rate limiters
IAM_RATE_LIMITER = TokenBucket(rate=20.0, capacity=100.0)   # Conservative for IAM
EC2_RATE_LIMITER = TokenBucket(rate=50.0, capacity=200.0)
S3_RATE_LIMITER = TokenBucket(rate=100.0, capacity=500.0)
KMS_RATE_LIMITER = TokenBucket(rate=50.0, capacity=200.0)
```

### 11.3 TypeScript SDK

The TypeScript SDK is a fully independent implementation of DriftFinder for Node.js environments. It does not call the Python CLI. It reimplements the NRM, parsers, runtime queries, and detection engine in TypeScript.

**Package name:** `@driftfinder/sdk`

**Repository structure (inside monorepo or separate repo):**
```
packages/sdk/
├── src/
│   ├── index.ts
│   ├── engine.ts
│   ├── models/
│   │   ├── nrm.ts
│   │   ├── findings.ts
│   │   └── enums.ts
│   ├── parsers/
│   │   ├── base.ts
│   │   ├── terraform.ts
│   │   ├── cloudformation.ts
│   │   └── pulumi.ts
│   ├── runtime/
│   │   ├── aws/
│   │   │   ├── s3.ts
│   │   │   ├── ec2.ts
│   │   │   └── ...
│   ├── mappers/
│   │   └── cis.ts
│   └── reporters/
│       ├── json.ts
│       └── html.ts
├── tests/
├── tsconfig.json
└── package.json
```

**TypeScript NRM example:**
```typescript
// Immutable NRM using TypeScript readonly
export type EncryptionAlgorithm = 'NONE' | 'AES256' | 'aws:kms';

export interface NRMBase {
  readonly resourceId: string;
  readonly resourceName: string;
  readonly iacTool: IaCTool;
  readonly region: string;
  readonly accountId: string;
}

export interface NRMS3Bucket extends NRMBase {
  readonly serverSideEncryptionEnabled: boolean | null;
  readonly encryptionAlgorithm: EncryptionAlgorithm | null;
  readonly publicAccessBlockEnabled: boolean | null;
  readonly blockPublicAcls: boolean | null;
  readonly ignorePublicAcls: boolean | null;
  readonly blockPublicPolicy: boolean | null;
  readonly restrictPublicBuckets: boolean | null;
  readonly versioningEnabled: boolean | null;
  readonly mfaDeleteEnabled: boolean | null;
  readonly accessLoggingEnabled: boolean | null;
}

// Public SDK surface
export class DriftFinderEngine {
  constructor(config: DriftFinderConfig) {}
  async scan(): Promise<ScanResult> {}
  async scanAsync(): Promise<ScanResult> {}
}
```

### 11.4 AI Fix Suggestions

```python
# Phase 2: AI module

import json
import os
from typing import Optional
from driftfinder.models.findings import DriftFinding


class AIModule:
    """
    Optional AI-powered fix suggestion module.
    Requires user-supplied API key.
    Never auto-applies fixes. Always requires human review.
    """
    
    SUPPORTED_PROVIDERS = ['anthropic', 'openai']
    
    def __init__(self, provider: str, api_key: str, model: Optional[str] = None):
        if provider not in self.SUPPORTED_PROVIDERS:
            raise ValueError(f"Unsupported provider: {provider}")
        self.provider = provider
        self.api_key = api_key
        self.model = model or self._default_model()
    
    def suggest_fix(
        self, 
        finding: DriftFinding, 
        source_block: Optional[str] = None
    ) -> dict:
        """
        Generate an IaC fix suggestion for a DriftFinding.
        Returns structured dict with fix details.
        Never executes anything.
        """
        prompt = self._build_fix_prompt(finding, source_block)
        raw_response = self._call_api(prompt)
        return self._parse_response(raw_response)
    
    def _build_fix_prompt(self, finding: DriftFinding, source_block: Optional[str]) -> str:
        source_context = (
            f"\nThe current IaC declaration for this resource:\n```\n{source_block}\n```\n"
            if source_block else ""
        )
        
        return f"""You are an IaC security remediation assistant for DriftFinder.

A configuration drift has been detected:
- IaC tool: {finding.iac_tool}
- Resource type: {finding.resource_type}
- Resource ID: {finding.resource_id}
- Property: {finding.property_path}
- Declared value: {finding.declared_value}
- Actual AWS value: {finding.actual_value}
- Drift type: {finding.drift_type}
- Severity: {finding.severity}
- CIS control violated: {', '.join(finding.cis_controls)}
- CIS description: {finding.cis_description}
{source_context}
Respond ONLY with valid JSON matching this exact schema (no markdown, no preamble):
{{
  "risk_explanation": "one sentence explaining the security risk",
  "remediation_code": "the exact IaC change needed in {finding.iac_tool} syntax",
  "apply_command": "the CLI command to apply this fix",
  "requires_review": true or false,
  "estimated_impact": "none|low|medium|high"
}}"""
    
    def _call_api(self, prompt: str) -> str:
        if self.provider == 'anthropic':
            import anthropic
            client = anthropic.Anthropic(api_key=self.api_key)
            response = client.messages.create(
                model=self.model,
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.content[0].text
        
        elif self.provider == 'openai':
            from openai import OpenAI
            client = OpenAI(api_key=self.api_key)
            response = client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            return response.choices[0].message.content
    
    def _parse_response(self, raw: str) -> dict:
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        return json.loads(clean)
    
    def _default_model(self) -> str:
        defaults = {
            'anthropic': 'claude-sonnet-4-5',
            'openai': 'gpt-4o'
        }
        return defaults[self.provider]
```

### 11.5 MCP Server

```python
# Phase 2: MCP server exposing DriftFinder as a tool

from mcp.server import Server
from mcp.server.stdio import stdio_server
from driftfinder.core.engine import DriftFinderEngine
from driftfinder.core.config import DriftFinderConfig


app = Server("driftfinder")


@app.tool()
async def scan_drift(
    iac_tool: str,
    state_source: str,
    region: str = "eu-west-2"
) -> dict:
    """
    Scan for configuration drift between IaC declared state and AWS runtime state.
    Returns a list of DriftFindings mapped to CIS controls.
    """
    config = DriftFinderConfig(
        iac_tool=iac_tool,
        state_file=state_source if iac_tool == 'terraform' else None,
        stack_name=state_source if iac_tool == 'cloudformation' else None,
        aws_region=region,
        mode='report-only'  # MCP server never fails, only reports
    )
    engine = DriftFinderEngine(config)
    result = engine.scan()
    return result.model_dump()


@app.tool()
async def get_compliance_status(
    iac_tool: str,
    state_source: str,
    cis_control: str
) -> dict:
    """Check compliance status for a specific CIS control."""
    # Filter findings by CIS control
    ...


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())
```

---

## 12. CLI Specification — Complete

### 12.1 Entry point

```python
# src/driftfinder/cli/main.py

import click
import sys
from driftfinder import __version__


@click.group()
@click.version_option(version=__version__, prog_name="driftfinder")
def cli():
    """
    DriftFinder - Open source IaC compliance drift detection.
    
    Detects drift between declared IaC state and live AWS runtime state,
    mapped to CIS AWS Foundations Benchmark v3.0 controls.
    """
    pass


cli.add_command(init_command, name='init')
cli.add_command(scan_command, name='scan')
cli.add_command(schedule_command, name='schedule')
cli.add_command(unschedule_command, name='unschedule')
cli.add_command(report_command, name='report')
# Phase 2 only:
# cli.add_command(remediate_command, name='remediate')
# cli.add_command(mcp_server_command, name='mcp-server')
```

### 12.2 init command

```
driftfinder init [--config PATH]

Interactive wizard that creates .driftfinder.yml.
Asks:
1. Which IaC tool? (terraform/cloudformation/pulumi)
2. State source:
   - Terraform: path to .tfstate or s3://bucket/path/to/state
   - CloudFormation: stack name
   - Pulumi: org/project/stack
3. AWS profile (default: uses environment/instance role)
4. AWS region (default: eu-west-2)
5. Fail on severity (default: CRITICAL)
6. Output format (default: both)

Validates that the state source is accessible before writing config.
```

### 12.3 scan command

```
driftfinder scan [OPTIONS]

Options:
  --config PATH          Config file path (default: .driftfinder.yml)
  --tool TEXT            Override IaC tool from config
  --state TEXT           Override state source from config
  --stack TEXT           Override stack name from config
  --output PATH          Output file path (without extension)
  --format [json|html|both]  Output format (default: both)
  --fail-on [CRITICAL|HIGH|MEDIUM|LOW]  Severity threshold for failure
  --mode [default|report-only]  default fails on findings, report-only never fails
  --enforce-iac          Force pass with documented override (requires --reason)
  --reason TEXT          Mandatory reason for --enforce-iac override
  --profile TEXT         AWS credentials profile
  --region TEXT          AWS region

Exit codes:
  0 = No findings at or above --fail-on severity
  1 = Findings detected at or above --fail-on severity
  2 = Scan error (config not found, AWS auth failure, etc.)

Output to terminal:
  Always print a summary table regardless of --format
  Colour-coded: CRITICAL=red, HIGH=yellow, MEDIUM=blue, LOW=grey
  If report-only mode, print INFO instead of ERROR

CI/CD example:
  driftfinder scan --fail-on HIGH --format json --output drift-report
```

### 12.4 schedule command

```
driftfinder schedule [OPTIONS]

Options:
  --interval TEXT     Scan interval: 15m, 30m, 1h, 6h, 1d (default: 15m)
  --config PATH       Config file to use in scheduled scans
  --output PATH       Directory for scan output files
  --notify-slack TEXT Slack webhook URL for findings notifications
  --notify-severity [CRITICAL|HIGH|MEDIUM|LOW]  Minimum severity to notify

Creates a crontab entry that runs driftfinder scan --mode report-only
on the configured schedule.

Scheduled scans:
  - Always run in report-only mode (never fail the cron job itself)
  - Write findings to dated files in output directory
  - Send Slack notification if findings meet severity threshold
  - Log to system log for visibility
```

### 12.5 report command

```
driftfinder report [OPTIONS]

Options:
  --input PATH        Path to a previous JSON scan result
  --format [json|html|both]  Output format
  --output PATH       Output path

Re-renders a previous scan result in the requested format.
Useful for generating HTML from a stored JSON report.
```

### 12.6 .driftfinder.yml example

```yaml
# .driftfinder.yml
# Generated by: driftfinder init

iac_tool: terraform
state_file: s3://my-company-tf-state/prod/terraform.tfstate
aws_region: eu-west-2
aws_profile: production
fail_on: CRITICAL
output_format: both

# Optional: scheduled scan output directory
schedule:
  output_dir: ./drift-reports

# Optional: Slack notifications (Phase 2)
# notify:
#   slack:
#     webhook: https://hooks.slack.com/services/xxx/yyy/zzz
#     on_severity: HIGH

# Optional: AI fix suggestions (Phase 2)
# ai:
#   provider: anthropic
#   # API key should be in ANTHROPIC_API_KEY environment variable
```

---

## 13. Test Strategy

### 13.1 Principles

1. No test should require live AWS credentials
2. Unit tests mock all AWS calls via moto
3. Integration tests mock all AWS calls via moto with realistic responses
4. E2E tests use LocalStack to simulate real AWS APIs locally
5. Every parser is tested against real fixture files (sample .tfstate, CF templates, Pulumi exports)
6. Every NRM property mapping has a test
7. Every CIS control mapping has a test
8. CLI commands are tested via Click's test runner
9. Minimum coverage: 80% Phase 1, 85% Phase 2

### 13.2 Unit test patterns

```python
# tests/unit/parsers/test_terraform.py

import pytest
import json
from pathlib import Path
from driftfinder.parsers.terraform import TerraformParser
from driftfinder.models.nrm import NRMS3Bucket


FIXTURES_DIR = Path(__file__).parent.parent.parent / "fixtures" / "tfstate"


class TestTerraformS3Parser:
    
    def test_parses_encrypted_bucket(self):
        """Parser correctly extracts encryption settings from .tfstate."""
        fixture_path = FIXTURES_DIR / "s3_encrypted.json"
        parser = TerraformParser()
        resources = list(parser.parse(str(fixture_path)))
        
        s3_resources = [r for r in resources if isinstance(r, NRMS3Bucket)]
        assert len(s3_resources) == 1
        assert s3_resources[0].server_side_encryption_enabled is True
        assert s3_resources[0].encryption_algorithm == "AES256"
    
    def test_parses_bucket_without_encryption(self):
        """Parser returns None for encryption when not declared in state."""
        fixture_path = FIXTURES_DIR / "s3_no_encryption.json"
        parser = TerraformParser()
        resources = list(parser.parse(str(fixture_path)))
        
        s3_resources = [r for r in resources if isinstance(r, NRMS3Bucket)]
        assert s3_resources[0].server_side_encryption_enabled is None
    
    def test_handles_modern_split_resource_format(self):
        """Parser merges aws_s3_bucket and aws_s3_bucket_server_side_encryption_configuration."""
        fixture_path = FIXTURES_DIR / "s3_modern_split_format.json"
        parser = TerraformParser()
        resources = list(parser.parse(str(fixture_path)))
        
        s3_resources = [r for r in resources if isinstance(r, NRMS3Bucket)]
        assert s3_resources[0].block_public_acls is True
```

```python
# tests/unit/runtime/test_s3.py

import pytest
from unittest.mock import patch, MagicMock
from moto import mock_aws
import boto3
from driftfinder.runtime.aws.s3 import S3RuntimeQuerier
from driftfinder.models.nrm import NRMS3Bucket


@mock_aws
class TestS3RuntimeQuerier:
    
    def setup_method(self):
        """Create a real S3 bucket in moto for testing."""
        self.s3 = boto3.client('s3', region_name='eu-west-2')
        self.s3.create_bucket(
            Bucket='test-bucket',
            CreateBucketConfiguration={'LocationConstraint': 'eu-west-2'}
        )
    
    def test_detects_missing_encryption(self):
        """Querier returns server_side_encryption_enabled=False when no encryption configured."""
        querier = S3RuntimeQuerier(region='eu-west-2')
        result = querier.query_bucket('test-bucket')
        
        assert result.server_side_encryption_enabled is False
    
    def test_detects_encryption_present(self):
        """Querier returns correct encryption algorithm when encryption is configured."""
        self.s3.put_bucket_encryption(
            Bucket='test-bucket',
            ServerSideEncryptionConfiguration={
                'Rules': [{'ApplyServerSideEncryptionByDefault': {'SSEAlgorithm': 'AES256'}}]
            }
        )
        querier = S3RuntimeQuerier(region='eu-west-2')
        result = querier.query_bucket('test-bucket')
        
        assert result.server_side_encryption_enabled is True
        assert result.encryption_algorithm == 'AES256'
```

```python
# tests/unit/core/test_engine.py

import pytest
from unittest.mock import patch, MagicMock
from driftfinder.core.engine import DriftFinderEngine
from driftfinder.core.config import DriftFinderConfig
from driftfinder.models.nrm import NRMS3Bucket
from driftfinder.models.enums import Severity, DriftType


class TestDriftDetection:
    
    def test_detects_encryption_drift(self):
        """Engine correctly identifies encryption drift between declared and actual state."""
        declared = NRMS3Bucket(
            resource_id='my-bucket',
            resource_name='my-bucket',
            iac_tool='terraform',
            region='eu-west-2',
            account_id='123456789012',
            server_side_encryption_enabled=True,
            encryption_algorithm='AES256'
        )
        actual = NRMS3Bucket(
            resource_id='my-bucket',
            resource_name='my-bucket',
            iac_tool='terraform',
            region='eu-west-2',
            account_id='123456789012',
            server_side_encryption_enabled=False,
            encryption_algorithm=None
        )
        
        engine = DriftFinderEngine.__new__(DriftFinderEngine)
        findings = engine._detect_drift(declared, actual)
        
        assert len(findings) >= 1
        encryption_finding = next(
            f for f in findings if f.property_path == 'server_side_encryption_enabled'
        )
        assert encryption_finding.declared_value is True
        assert encryption_finding.actual_value is False
        assert encryption_finding.drift_type == DriftType.MODIFIED
        assert '2.1.1' in encryption_finding.cis_controls
    
    def test_no_findings_when_state_matches(self):
        """Engine returns no findings when declared and actual state are identical."""
        resource = NRMS3Bucket(
            resource_id='my-bucket',
            resource_name='my-bucket', 
            iac_tool='terraform',
            region='eu-west-2',
            account_id='123456789012',
            server_side_encryption_enabled=True,
            encryption_algorithm='AES256',
            public_access_block_enabled=True
        )
        engine = DriftFinderEngine.__new__(DriftFinderEngine)
        findings = engine._detect_drift(resource, resource)
        
        assert len(findings) == 0
    
    def test_none_declared_does_not_produce_finding(self):
        """When a property is None in declared state, no finding is produced."""
        declared = NRMS3Bucket(
            resource_id='my-bucket',
            resource_name='my-bucket',
            iac_tool='cloudformation',
            region='eu-west-2',
            account_id='123456789012',
            server_side_encryption_enabled=None  # Not declared in template
        )
        actual = NRMS3Bucket(
            resource_id='my-bucket',
            resource_name='my-bucket',
            iac_tool='cloudformation',
            region='eu-west-2',
            account_id='123456789012',
            server_side_encryption_enabled=False  # Not configured in AWS
        )
        engine = DriftFinderEngine.__new__(DriftFinderEngine)
        findings = engine._detect_drift(declared, actual)
        
        # None declared means not specified, should not create finding
        assert not any(f.property_path == 'server_side_encryption_enabled' for f in findings)
```

### 13.3 Integration tests

```python
# tests/integration/test_drift_detection.py

import pytest
from moto import mock_aws
import boto3
import json
from pathlib import Path
from driftfinder.core.engine import DriftFinderEngine
from driftfinder.core.config import DriftFinderConfig, IaCTool


@mock_aws
class TestFullScanIntegration:
    
    def setup_method(self):
        """Set up AWS resources in moto that represent a drifted state."""
        # Create S3 bucket without encryption (simulating drift)
        self.s3 = boto3.client('s3', region_name='eu-west-2')
        self.s3.create_bucket(
            Bucket='driftfinder-test',
            CreateBucketConfiguration={'LocationConstraint': 'eu-west-2'}
        )
        # Deliberately NOT configuring encryption
    
    def test_detects_encryption_drift_end_to_end(self, tmp_path):
        """Full scan detects encryption drift declared in .tfstate vs actual AWS state."""
        # Create a .tfstate that declares encryption enabled
        tfstate = {
            "version": 4,
            "resources": [{
                "mode": "managed",
                "type": "aws_s3_bucket_server_side_encryption_configuration",
                "name": "test",
                "instances": [{
                    "attributes": {
                        "bucket": "driftfinder-test",
                        "rule": [{
                            "apply_server_side_encryption_by_default": [{
                                "sse_algorithm": "AES256"
                            }]
                        }]
                    }
                }]
            }]
        }
        state_file = tmp_path / "terraform.tfstate"
        state_file.write_text(json.dumps(tfstate))
        
        config = DriftFinderConfig(
            iac_tool=IaCTool.TERRAFORM,
            state_file=str(state_file),
            aws_region='eu-west-2'
        )
        engine = DriftFinderEngine(config)
        result = engine.scan()
        
        assert not result.compliant
        assert result.critical_count + result.high_count > 0
        encryption_findings = [
            f for f in result.findings 
            if f.property_path == 'server_side_encryption_enabled'
        ]
        assert len(encryption_findings) == 1
        assert '2.1.1' in encryption_findings[0].cis_controls
```

### 13.4 E2E tests with LocalStack

```python
# tests/e2e/test_localstack.py

import pytest
import boto3
import subprocess


# These tests require LocalStack to be running
# Run: docker-compose up localstack -d
# Then: pytest tests/e2e/ --localstack

LOCALSTACK_ENDPOINT = "http://localhost:4566"

@pytest.fixture(scope="session")
def localstack_s3():
    """Create a boto3 S3 client pointed at LocalStack."""
    return boto3.client(
        's3',
        endpoint_url=LOCALSTACK_ENDPOINT,
        region_name='eu-west-2',
        aws_access_key_id='test',
        aws_secret_access_key='test'
    )


@pytest.mark.localstack
class TestLocalStackE2E:
    
    def test_cli_scan_against_localstack(self, localstack_s3, tmp_path):
        """Full CLI scan against LocalStack returns expected results."""
        # Create bucket in LocalStack without encryption
        localstack_s3.create_bucket(
            Bucket='e2e-test-bucket',
            CreateBucketConfiguration={'LocationConstraint': 'eu-west-2'}
        )
        
        # Create .tfstate declaring encryption
        # ... (setup)
        
        # Run CLI
        result = subprocess.run(
            ['driftfinder', 'scan', '--config', str(config_file), '--format', 'json'],
            capture_output=True,
            text=True,
            env={**os.environ, 'AWS_ENDPOINT_URL': LOCALSTACK_ENDPOINT}
        )
        
        assert result.returncode == 1  # Findings detected
        output = json.loads(result.stdout)
        assert not output['compliant']
```

### 13.5 Fixture files required

Create realistic fixture files for all parsers:

```
tests/fixtures/tfstate/
├── s3_compliant_legacy.json        # aws_s3_bucket with all properties set
├── s3_compliant_modern.json        # Split resource format
├── s3_drifted_no_encryption.json   # Declares encryption, matches drifted state
├── s3_no_encryption_declared.json  # Encryption not declared (None case)
├── security_group_compliant.json
├── security_group_ssh_open.json
├── iam_policy_compliant.json
├── iam_policy_wildcard.json
├── rds_compliant.json
├── rds_public.json
├── ebs_encrypted.json
├── cloudtrail_compliant.json
├── vpc_compliant.json
└── kms_compliant.json

tests/fixtures/cloudformation/
├── s3_compliant.yaml
├── s3_no_encryption.yaml
├── security_group_compliant.yaml
└── ...

tests/fixtures/pulumi/
├── s3_compliant_state.json
├── s3_drifted_state.json
└── ...
```

---

## 14. Security Requirements

These apply from Phase 1. Do not defer security to Phase 2.

### 14.1 IAM least privilege

Document the minimum IAM policy required to run DriftFinder. Include this in README.md and as a Terraform/CloudFormation template in the docs:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetBucketEncryption",
        "s3:GetBucketPublicAccessBlock",
        "s3:GetBucketVersioning",
        "s3:GetBucketLogging",
        "s3:GetBucketPolicy",
        "ec2:DescribeSecurityGroups",
        "ec2:DescribeVolumes",
        "ec2:DescribeVpcs",
        "ec2:DescribeFlowLogs",
        "ec2:DescribeNetworkAcls",
        "iam:GetPolicy",
        "iam:GetPolicyVersion",
        "iam:GetRolePolicy",
        "rds:DescribeDBInstances",
        "cloudtrail:DescribeTrails",
        "cloudtrail:GetTrailStatus",
        "kms:DescribeKey",
        "kms:GetKeyRotationStatus",
        "kms:GetKeyPolicy",
        "cloudformation:DescribeStackResources",
        "cloudformation:GetTemplate"
      ],
      "Resource": "*"
    }
  ]
}
```

### 14.2 No credential storage

DriftFinder NEVER stores credentials. It reads from:
1. Standard AWS credential chain (environment variables, ~/.aws/credentials, instance role)
2. Explicit --profile flag
3. .driftfinder.yml aws_profile field (profile name only, never keys)

If any code path stores a secret key, API key, or credential to disk, it is a security bug.

### 14.3 Input validation

All user inputs (config file values, CLI flags, state file paths) are validated via Pydantic before use. State files are parsed with safe JSON/YAML loaders. Never use yaml.load() — always yaml.safe_load().

### 14.4 Dependency management

pyproject.toml must pin minimum versions for all dependencies. Run pip-audit on every CI run. Fix any HIGH or CRITICAL vulnerabilities before merging.

### 14.5 SECURITY.md

Create SECURITY.md at repository root containing:
- Supported versions
- How to report a vulnerability (email address or GitHub private disclosure)
- Response time commitment (acknowledge within 72 hours, patch within 30 days for CRITICAL)

### 14.6 .gitignore

Must include:
```
.driftfinder.yml          # May contain profile names
*.tfstate                 # May contain sensitive values
drift-reports/            # May contain infrastructure details
.env
*.pem
*.key
```

### 14.7 Phase 2 additions

- SBOM generation on every release via `pip-licenses` and `cyclonedx-py`
- Signed releases via sigstore/cosign
- GitHub Actions dependency review on every PR
- CodeQL analysis weekly

---

## 15. CI/CD Pipeline

### 15.1 ci.yml (every PR)

```yaml
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install ruff black isort mypy
      - run: ruff check src/ tests/
      - run: black --check src/ tests/
      - run: isort --check-only src/ tests/
      - run: mypy src/driftfinder --strict

  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.11', '3.12']
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - run: pip install -e ".[dev]"
      - run: pytest tests/unit tests/integration --cov=driftfinder --cov-report=xml
      - uses: codecov/codecov-action@v3

  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install pip-audit
      - run: pip-audit --requirement requirements.txt

  e2e:
    runs-on: ubuntu-latest
    services:
      localstack:
        image: localstack/localstack:3.0
        ports:
          - 4566:4566
        env:
          SERVICES: s3,ec2,iam,rds,kms,cloudtrail
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install -e ".[dev]"
      - run: pytest tests/e2e --localstack
        env:
          AWS_DEFAULT_REGION: eu-west-2
          AWS_ACCESS_KEY_ID: test
          AWS_SECRET_ACCESS_KEY: test
```

### 15.2 release.yml (on tag)

```yaml
name: Release

on:
  push:
    tags:
      - 'v*'

jobs:
  publish-pypi:
    runs-on: ubuntu-latest
    environment: release
    permissions:
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install hatch
      - run: hatch build
      - uses: pypa/gh-action-pypi-publish@release/v1
        # Uses trusted publishing, no API token needed

  create-github-release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: softprops/action-gh-release@v1
        with:
          body_path: CHANGELOG.md
          files: dist/*
```

---

## 16. Distribution

### 16.1 pyproject.toml

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "driftfinder"
version = "1.0.0"
description = "Open source IaC compliance drift detection for AWS"
readme = "README.md"
license = { text = "Apache-2.0" }
authors = [
  { name = "Emeka Victor Ubahakwe" }
]
keywords = [
  "iac", "drift-detection", "aws", "terraform", 
  "cloudformation", "pulumi", "compliance", "cis", "devsecops"
]
classifiers = [
  "Development Status :: 4 - Beta",
  "Environment :: Console",
  "Intended Audience :: Developers",
  "Intended Audience :: System Administrators",
  "License :: OSI Approved :: Apache Software License",
  "Programming Language :: Python :: 3",
  "Programming Language :: Python :: 3.11",
  "Programming Language :: Python :: 3.12",
  "Topic :: Security",
  "Topic :: System :: Systems Administration",
]
requires-python = ">=3.11"
dependencies = [
  "click>=8.1.0",
  "pydantic>=2.5.0",
  "boto3>=1.34.0",
  "botocore>=1.34.0",
  "PyYAML>=6.0.0",
  "Jinja2>=3.1.0",
  "tenacity>=8.2.0",
  "rich>=13.0.0",  # Terminal output formatting
]

[project.optional-dependencies]
dev = [
  "pytest>=7.4.0",
  "pytest-cov>=4.1.0",
  "pytest-asyncio>=0.23.0",
  "moto[s3,ec2,iam,rds,kms,cloudtrail]>=4.2.0",
  "ruff>=0.1.0",
  "black>=23.0.0",
  "isort>=5.12.0",
  "mypy>=1.7.0",
  "pip-audit>=2.6.0",
  "boto3-stubs[s3,ec2,iam,rds,kms,cloudtrail,cloudformation]>=1.34.0",
]
ai = [
  "anthropic>=0.18.0",
  "openai>=1.0.0",
]

[project.scripts]
driftfinder = "driftfinder.cli.main:cli"

[project.urls]
Homepage = "https://github.com/Victorthedev/driftfinder"
Documentation = "https://driftfinder.readthedocs.io"
Repository = "https://github.com/Victorthedev/driftfinder"
Issues = "https://github.com/Victorthedev/driftfinder/issues"
Changelog = "https://github.com/Victorthedev/driftfinder/blob/main/CHANGELOG.md"

[tool.hatch.build.targets.wheel]
packages = ["src/driftfinder"]

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "-v --tb=short"
markers = [
  "localstack: marks tests requiring LocalStack (deselect with -m 'not localstack')",
  "slow: marks slow-running tests",
]

[tool.coverage.run]
source = ["src/driftfinder"]
omit = ["*/tests/*", "*/fixtures/*"]

[tool.mypy]
strict = true
python_version = "3.11"
ignore_missing_imports = true

[tool.ruff]
line-length = 100
target-version = "py311"
select = ["E", "F", "W", "I", "N", "UP", "S", "B", "A", "C4", "T20"]
ignore = ["S101"]  # Allow assert in tests

[tool.black]
line-length = 100
target-version = ["py311"]

[tool.isort]
profile = "black"
line_length = 100
```

### 16.2 Semantic versioning

- 1.0.0 = Phase 1 complete (8 resource types, 3 IaC tools, CLI, dissertation experiment done)
- 1.1.0 = Phase 2 async + rate limiting + all 58 controls
- 1.2.0 = TypeScript SDK published to npm
- 1.3.0 = AI fix suggestions
- 1.4.0 = MCP server
- 1.5.0 = Remediation mode
- 2.0.0 = Azure/GCP adapters

---

## 17. Documentation Requirements

### 17.1 README.md structure

```markdown
# DriftFinder

> Open source IaC compliance drift detection for AWS.

[badges: PyPI version, Python versions, Licence, CI status, Coverage]

## What it does
[One paragraph, plain language, no jargon]

## Quick start
\`\`\`bash
pip install driftfinder
driftfinder init
driftfinder scan
\`\`\`

[15-second terminal demo GIF goes here]

## Sample output
[Show a real terminal output with findings]

## Why DriftFinder
[One paragraph explaining the gap: driftctl is dead, existing tools are single-IaC, 
AWS Config has no IaC awareness]

## Supported tools and resources
[Table: IaC tool | Status]
[Table: Resource type | CIS controls covered | Status]

## Documentation
[Links to full docs]

## Contributing
[Link to CONTRIBUTING.md]

## Licence
Apache 2.0
```

### 17.2 Architecture Decision Records

Create an ADR for each major design decision:
- ADR-001: Why Python first, TypeScript second
- ADR-002: NRM design — frozen dataclasses not Pydantic
- ADR-003: None vs False for undeclared properties
- ADR-004: moto for unit tests, LocalStack for E2E
- ADR-005: Click over argparse or Typer

### 17.3 CONTRIBUTING.md must include

- Development setup instructions
- How to add a new resource type adapter
- How to add a new IaC tool parser
- How to add new CIS control mappings
- Test requirements for PRs
- Code style guide
- Conventional commit message format

---

## 18. Research Notes and Known Challenges

This section documents known challenges discovered during research. Add to this as you discover more.

### 18.1 NRM edge cases

**CloudFormation implicit defaults:** A CF template that does not specify S3 encryption may still result in an encrypted bucket if account-level S3 encryption defaults are configured. DriftFinder cannot know about account-level defaults from the template alone. When encryption_algorithm is None in declared state but False in actual, produce a WARN-level finding rather than a drift finding.

**Terraform provider version differences:** The Terraform AWS provider changed the S3 resource model significantly in v4. State files from pre-v4 provider use a monolithic aws_s3_bucket resource. State files from v4+ split properties into separate resources. The parser must detect which format is being used. Check the `schema_version` field in the resource instance.

**Pulumi Python vs TypeScript property names:** Pulumi state files use camelCase property names regardless of whether the program was written in Python or TypeScript. The parser always reads camelCase from the state file.

### 18.2 AWS API quirks

**S3 NoSuchConfiguration exceptions:** Several S3 API calls throw NoSuchConfiguration rather than returning an empty result when the feature is not configured. Handle these explicitly and map to property value False.

**IAM eventual consistency:** IAM changes can take up to 60 seconds to propagate globally. When scanning immediately after an IAM change, the API may return the old value. The retry logic with exponential backoff should handle transient mismatches, but note in the dissertation that scans run immediately after IAM changes may have a brief window of inconsistency.

**KMS key types:** Only customer-managed symmetric keys support automatic rotation. AWS-managed keys and asymmetric keys should return None for key_rotation_enabled, not False. Attempting to call get_key_rotation_status on an AWS-managed key will return a specific error. Handle this gracefully.

**RDS cluster vs instance:** RDS has both clusters (Aurora) and instances. The dissertation scope covers instances (aws_db_instance). Clusters use a different API (describe_db_clusters). Be explicit about this scope boundary.

### 18.3 Research adaptations

This is a research project. The implementation may reveal that some NRM properties are not reliably detectable via the AWS APIs as specified. When this happens:

1. Document the limitation clearly in the code with a comment
2. Add a note to the dissertation limitations section
3. Add a test that demonstrates the limitation
4. Do NOT silently skip the property

The dissertation's value is partly in documenting what works and what does not. A well-documented limitation is more academically valuable than a quietly dropped property.

### 18.4 Controlled experiment notes

The controlled experiment provisions three identical AWS environments, one per IaC tool, and injects 24 drift scenarios. For the experiment to be reproducible:

1. All three environments must be provisioned in the same AWS region (eu-west-2)
2. All initial configurations must be verified against CIS controls before drift injection begins
3. Each drift injection must be logged in the ground truth file before DriftFinder is run
4. DriftFinder must be run within 5 minutes of each injection to avoid AWS eventual consistency affecting results
5. Each environment must be completely destroyed and reprovisioned between experiment runs to avoid state contamination

### 18.5 Open questions to resolve during development

1. How does DriftFinder handle a Terraform workspace with multiple state files? Scan each separately or merged?
2. For IAM wildcard detection: should a policy with `Action: "s3:*"` trigger has_wildcard_action? Currently the spec says only literal `*`. Revisit this during implementation.
3. CloudFormation nested stacks: should DriftFinder recurse into nested stacks? Currently out of scope but worth noting.
4. What is the right behaviour when an AWS resource declared in IaC has been deleted from AWS entirely? This is DELETED drift type but the runtime querier will get a 404. Handle gracefully.

---

## Appendix A: Example .tfstate fixtures

These are minimal but realistic fixture files for testing. The parser must handle all fields even if not all are present.

### S3 Bucket (modern format)
```json
{
  "version": 4,
  "terraform_version": "1.6.0",
  "resources": [
    {
      "mode": "managed",
      "type": "aws_s3_bucket",
      "name": "driftfinder_test",
      "provider": "provider[\"registry.terraform.io/hashicorp/aws\"]",
      "instances": [
        {
          "schema_version": 0,
          "attributes": {
            "id": "driftfinder-test-bucket",
            "bucket": "driftfinder-test-bucket",
            "region": "eu-west-2"
          }
        }
      ]
    },
    {
      "mode": "managed",
      "type": "aws_s3_bucket_server_side_encryption_configuration",
      "name": "driftfinder_test",
      "instances": [
        {
          "schema_version": 0,
          "attributes": {
            "bucket": "driftfinder-test-bucket",
            "rule": [
              {
                "apply_server_side_encryption_by_default": [
                  {
                    "sse_algorithm": "AES256",
                    "kms_master_key_id": ""
                  }
                ],
                "bucket_key_enabled": false
              }
            ]
          }
        }
      ]
    },
    {
      "mode": "managed",
      "type": "aws_s3_bucket_public_access_block",
      "name": "driftfinder_test",
      "instances": [
        {
          "schema_version": 0,
          "attributes": {
            "bucket": "driftfinder-test-bucket",
            "block_public_acls": true,
            "block_public_policy": true,
            "ignore_public_acls": true,
            "restrict_public_buckets": true
          }
        }
      ]
    }
  ]
}
```

---

## Appendix B: Example DriftFinder output

### Terminal output (CRITICAL finding)
```
DriftFinder v1.0.0 — Scan Results
Scanned: 8 resources | Tool: terraform | Region: eu-west-2
Timestamp: 2025-09-15T14:32:01Z

FINDINGS: 2 total (1 CRITICAL, 1 HIGH)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[CRITICAL] NRMSecurityGroup — sg-0abc123def456789
  Property:  unrestricted_ssh_ingress
  Declared:  False
  Actual:    True
  CIS:       5.2 — Ensure no security groups allow ingress from 0.0.0.0/0 to port 22
  
[HIGH]     NRMS3Bucket — driftfinder-test-bucket
  Property:  server_side_encryption_enabled
  Declared:  True
  Actual:    False
  CIS:       2.1.1 — Ensure all S3 buckets employ encryption-at-rest

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Report written to: drift-report.json, drift-report.html
Exit code: 1 (CRITICAL findings detected)
```

### JSON output structure
```json
{
  "scan_timestamp": "2025-09-15T14:32:01Z",
  "iac_tool": "terraform",
  "state_source": "s3://my-company-tf-state/prod/terraform.tfstate",
  "resources_scanned": 8,
  "resources_with_drift": 2,
  "compliant": false,
  "scan_duration_seconds": 12.4,
  "critical_count": 1,
  "high_count": 1,
  "medium_count": 0,
  "low_count": 0,
  "findings": [
    {
      "resource_type": "NRMSecurityGroup",
      "resource_id": "sg-0abc123def456789",
      "resource_name": "web-sg",
      "iac_tool": "terraform",
      "property_path": "unrestricted_ssh_ingress",
      "declared_value": false,
      "actual_value": true,
      "drift_type": "MODIFIED",
      "severity": "CRITICAL",
      "cis_controls": ["5.2"],
      "cis_description": "Ensure no security groups allow ingress from 0.0.0.0/0 to port 22",
      "detected_at": "2025-09-15T14:32:01Z"
    }
  ]
}
```

---

*DriftFinder Build Specification v1.0*
*Apache 2.0 Licensed*
*This document is the living specification for the DriftFinder project.*
*Update it as the project evolves.*